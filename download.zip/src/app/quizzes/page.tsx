import Image from 'next/image';
import Link from 'next/link';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Puzzle } from 'lucide-react';
import { QUIZZES_DATA } from '@/lib/constants';

export default function QuizzesPage() {
  return (
    <div className="flex flex-col items-center">
      <section className="w-full py-8 md:py-12 bg-primary/10">
        <div className="container px-4 md:px-6 text-center">
          <Puzzle className="h-16 w-16 mx-auto text-primary mb-4" />
          <h1 className="text-4xl font-bold tracking-tight">Curriculum Quizzes</h1>
          <p className="mt-3 max-w-xl mx-auto text-lg text-foreground/80">
            Test your knowledge with interactive quizzes and mini-games aligned with the CBSE syllabus.
          </p>
        </div>
      </section>

      <section className="w-full py-10 md:py-16">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {QUIZZES_DATA.map((quiz) => (
              <Card key={quiz.id} className="flex flex-col overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader className="p-0">
                   <Image
                    src={`https://picsum.photos/400/200?random=${quiz.id}`}
                    alt={quiz.title}
                    width={400}
                    height={200}
                    className="w-full h-48 object-cover"
                    data-ai-hint={quiz.imageHint}
                  />
                </CardHeader>
                <CardContent className="p-6 flex flex-col flex-grow">
                  <div className="flex items-center gap-3 mb-3">
                     <quiz.icon className="h-7 w-7 text-primary" />
                    <CardTitle className="text-xl font-semibold">{quiz.title}</CardTitle>
                  </div>
                  <CardDescription className="text-foreground/70 mb-4 flex-grow">
                    Subject: {quiz.subject}
                  </CardDescription>
                  <Button variant="default" className="mt-auto group w-full bg-primary hover:bg-primary/90" disabled>
                    {/* <Link href={`/quizzes/${quiz.id}`}> */}
                      Start Quiz
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    {/* </Link> */}
                  </Button>
                  <p className="text-xs text-muted-foreground mt-2 text-center">Feature coming soon!</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
