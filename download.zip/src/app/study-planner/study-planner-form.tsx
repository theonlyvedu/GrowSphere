'use client';

import { useState } from 'react';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2, Wand2, AlertCircle, CheckCircle2 } from 'lucide-react';
import { generateStudyScheduleAction } from './actions';
import type { StudyScheduleGeneratorOutput } from '@/ai/flows/study-schedule-generator';

const FormSchema = z.object({
  subjects: z.string().min(1, "Please enter at least one subject, separated by commas."),
  learningHabits: z.string().min(10, "Please describe your learning habits (min 10 characters)."),
  quizScores: z.string().min(1, "Please enter quiz scores as JSON (e.g. {\"Math\": 80}).")
    .refine((val) => {
      try {
        const parsed = JSON.parse(val);
        return typeof parsed === 'object' && !Array.isArray(parsed) && parsed !== null && Object.keys(parsed).length > 0;
      } catch (e) {
        return false;
      }
    }, "Quiz scores must be a valid non-empty JSON object (e.g., {\"Math\": 80, \"Science\": 75})."),
  academicGoals: z.string().min(10, "Please describe your academic goals (min 10 characters)."),
});

type FormData = z.infer<typeof FormSchema>;

export function StudyPlannerForm() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<StudyScheduleGeneratorOutput | null>(null);

  const form = useForm<FormData>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      subjects: '',
      learningHabits: '',
      quizScores: '',
      academicGoals: '',
    },
  });

  const onSubmit: SubmitHandler<FormData> = async (data) => {
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const subjectsArray = data.subjects.split(',').map(s => s.trim()).filter(s => s.length > 0);
      if (subjectsArray.length === 0) {
        form.setError('subjects', { type: 'manual', message: 'Please enter at least one valid subject.' });
        setIsLoading(false);
        return;
      }
      
      // The quizScores string is already validated as JSON by Zod, action will parse it.
      const parsedQuizScores = JSON.parse(data.quizScores);

      const response = await generateStudyScheduleAction({
        subjects: subjectsArray,
        learningHabits: data.learningHabits,
        quizScores: parsedQuizScores,
        academicGoals: data.academicGoals,
      });

      if (response.success && response.data) {
        setResult(response.data);
      } else {
        if (typeof response.error === 'string') {
          setError(response.error);
        } else if (response.error && 'formErrors' in response.error) {
          // Handle Zod validation errors
          const zodError = response.error as unknown as z.ZodError<FormData>;
          zodError.errors.forEach(err => {
            if (err.path.length > 0) {
              const fieldName = err.path[0] as keyof FormData;
              form.setError(fieldName, { type: 'manual', message: err.message });
            } else {
              setError(err.message); // General form error
            }
          });
        } else {
          setError('An unknown error occurred.');
        }
      }
    } catch (e) {
      console.error(e);
      setError('Failed to process request. Please ensure quiz scores are valid JSON.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-2xl">
      <CardHeader>
        <CardTitle className="text-3xl font-bold flex items-center gap-2">
          <Wand2 className="h-8 w-8 text-primary" />
          AI Study Planner
        </CardTitle>
        <CardDescription>
          Fill in your details below, and our AI will generate a personalized study schedule and recommendations for you.
        </CardDescription>
      </CardHeader>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div className="space-y-2">
            <Label htmlFor="subjects">Subjects (comma-separated)</Label>
            <Input id="subjects" placeholder="e.g., Math, Physics, Chemistry" {...form.register('subjects')} />
            {form.formState.errors.subjects && <p className="text-sm text-destructive">{form.formState.errors.subjects.message}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="learningHabits">Learning Habits</Label>
            <Textarea id="learningHabits" placeholder="e.g., Prefer studying in the morning, use flashcards for memorization..." {...form.register('learningHabits')} />
            {form.formState.errors.learningHabits && <p className="text-sm text-destructive">{form.formState.errors.learningHabits.message}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="quizScores">Quiz Scores (JSON format)</Label>
            <Textarea id="quizScores" placeholder='e.g., {"Math": 85, "Science": 70, "English": 92}' {...form.register('quizScores')} />
            {form.formState.errors.quizScores && <p className="text-sm text-destructive">{form.formState.errors.quizScores.message}</p>}
            <p className="text-xs text-muted-foreground">
              Enter scores as a JSON object. Example: <code className="bg-muted p-1 rounded">{"{\"Math\": 75, \"History\": 88}"}</code>
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="academicGoals">Academic Goals</Label>
            <Textarea id="academicGoals" placeholder="e.g., Score above 90% in all subjects, prepare for competitive exams..." {...form.register('academicGoals')} />
            {form.formState.errors.academicGoals && <p className="text-sm text-destructive">{form.formState.errors.academicGoals.message}</p>}
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isLoading} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Wand2 className="mr-2 h-4 w-4" />
                Generate Schedule
              </>
            )}
          </Button>
        </CardFooter>
      </form>

      {result && (
        <CardContent className="mt-6 border-t pt-6">
           <Alert variant="default" className="bg-green-50 border-green-300 dark:bg-green-900/30 dark:border-green-700">
              <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
              <AlertTitle className="font-semibold text-green-700 dark:text-green-300">Schedule Generated Successfully!</AlertTitle>
              <AlertDescription className="text-green-600 dark:text-green-400">
                Here's your personalized plan:
              </AlertDescription>
            </Alert>
          <div className="mt-4 space-y-6">
            <div>
              <h3 className="text-xl font-semibold text-primary mb-2">Your Personalized Study Schedule</h3>
              <div className="p-4 bg-muted rounded-md whitespace-pre-wrap text-sm leading-relaxed">
                {result.schedule}
              </div>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-accent mb-2">Recommendations</h3>
              <div className="p-4 bg-muted rounded-md whitespace-pre-wrap text-sm leading-relaxed">
                {result.recommendations}
              </div>
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
