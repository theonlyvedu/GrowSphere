import { StudyPlannerForm } from './study-planner-form';
import Image from 'next/image';

export default function StudyPlannerPage() {
  return (
    <div className="w-full max-w-4xl mx-auto py-8 px-4 md:px-0">
      <div className="mb-8 text-center">
        <Image 
            src="https://picsum.photos/600/200" 
            alt="AI Study Planner Banner"
            width={600}
            height={200}
            className="rounded-lg shadow-lg mx-auto mb-4"
            data-ai-hint="organized schedule planner"
        />
        <h1 className="text-4xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
          AI-Powered Study Planner
        </h1>
        <p className="mt-3 text-lg text-gray-600 dark:text-gray-300">
          Let our intelligent assistant craft the perfect study schedule for your success.
        </p>
      </div>
      <StudyPlannerForm />
    </div>
  );
}
