'use server';

import { studyScheduleGenerator, type StudyScheduleGeneratorInput, type StudyScheduleGeneratorOutput } from '@/ai/flows/study-schedule-generator';
import { z } from 'zod';

const StudyScheduleInputClientSchema = z.object({
  subjects: z.array(z.string()).min(1, "Please enter at least one subject."),
  learningHabits: z.string().min(10, "Please describe your learning habits (min 10 characters)."),
  quizScores: z.string().refine((val) => {
    try {
      const parsed = JSON.parse(val);
      return typeof parsed === 'object' && !Array.isArray(parsed) && parsed !== null;
    } catch (e) {
      return false;
    }
  }, "Quiz scores must be a valid JSON object (e.g., {\"Math\": 80, \"Science\": 75}).").transform((val) => JSON.parse(val) as Record<string, number>),
  academicGoals: z.string().min(10, "Please describe your academic goals (min 10 characters)."),
});


export async function generateStudyScheduleAction(
  input: StudyScheduleGeneratorInput
): Promise<{ success: boolean; data?: StudyScheduleGeneratorOutput; error?: string | z.ZodError<StudyScheduleGeneratorInput> }> {
  const validatedInput = StudyScheduleInputClientSchema.safeParse(input);

  if (!validatedInput.success) {
    return { success: false, error: validatedInput.error };
  }

  try {
    const result = await studyScheduleGenerator(validatedInput.data);
    return { success: true, data: result };
  } catch (error) {
    console.error("Error generating study schedule:", error);
    return { success: false, error: "Failed to generate study schedule. Please try again." };
  }
}
