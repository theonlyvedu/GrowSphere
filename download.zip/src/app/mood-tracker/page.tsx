'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Smile, CheckCircle, Loader2 } from 'lucide-react';
import { MOOD_OPTIONS } from '@/lib/constants';
import { useToast } from '@/hooks/use-toast';

export default function MoodTrackerPage() {
  const [selectedMood, setSelectedMood] = useState<string | undefined>(undefined);
  const [isLogging, setIsLogging] = useState(false);
  const [currentDate, setCurrentDate] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    setCurrentDate(new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));
  }, []);

  const handleLogMood = () => {
    if (!selectedMood) {
      toast({
        title: "No Mood Selected",
        description: "Please select a mood to log.",
        variant: "destructive",
      });
      return;
    }
    setIsLogging(true);
    // Simulate API call
    setTimeout(() => {
      setIsLogging(false);
      toast({
        title: "Mood Logged!",
        description: `Your mood (${selectedMood}) for ${currentDate} has been logged.`,
        action: <CheckCircle className="text-green-500" />,
      });
      //setSelectedMood(undefined); // Optionally reset selection
    }, 1500);
  };

  return (
    <div className="flex flex-col items-center">
      <section className="w-full py-8 md:py-12 bg-secondary/30">
        <div className="container px-4 md:px-6 text-center">
          <Smile className="h-16 w-16 mx-auto text-primary mb-4" />
          <h1 className="text-4xl font-bold tracking-tight">Mood Tracker</h1>
          <p className="mt-3 max-w-xl mx-auto text-lg text-foreground/80">
            Check in with yourself. Log your mood and find resources to support your well-being.
          </p>
        </div>
      </section>

      <section className="w-full py-10 md:py-16">
        <div className="container px-4 md:px-6 flex justify-center">
          <Card className="w-full max-w-lg shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl">How are you feeling today?</CardTitle>
              <CardDescription>
                {currentDate ? `It's ${currentDate}. Take a moment for a quick check-in.` : 'Loading date...'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <RadioGroup
                value={selectedMood}
                onValueChange={setSelectedMood}
                className="grid grid-cols-2 gap-4 md:grid-cols-4"
              >
                {MOOD_OPTIONS.map((mood) => (
                  <Label
                    key={mood.value}
                    htmlFor={`mood-${mood.value}`}
                    className={`flex flex-col items-center justify-center space-y-2 rounded-md border-2 p-4 hover:border-primary cursor-pointer transition-all
                                ${selectedMood === mood.value ? 'border-primary ring-2 ring-primary shadow-md' : 'border-muted'}`}
                  >
                    <RadioGroupItem value={mood.value} id={`mood-${mood.value}`} className="sr-only" />
                    <mood.icon className={`h-10 w-10 mb-1 ${selectedMood === mood.value ? 'text-primary' : 'text-muted-foreground'}`} />
                    <span className={`font-medium ${selectedMood === mood.value ? 'text-primary' : ''}`}>{mood.label}</span>
                  </Label>
                ))}
              </RadioGroup>
              {selectedMood && (
                 <div className="pt-4 text-center">
                    <p className="text-sm text-muted-foreground">You've selected: <span className="font-semibold text-primary">{selectedMood}</span></p>
                 </div>
              )}
            </CardContent>
            <CardFooter>
              <Button onClick={handleLogMood} disabled={isLogging || !selectedMood} className="w-full">
                {isLogging ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Logging...
                  </>
                ) : (
                  "Log Mood"
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </section>

      <section className="w-full py-10 md:py-16 bg-muted/30">
        <div className="container px-4 md:px-6 text-center">
           <h2 className="text-2xl font-semibold mb-6">Suggested Activities</h2>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "Quick Meditation", description: "A 5-minute guided meditation to calm your mind.", hint: "meditation calm" },
              { title: "Positive Affirmations", description: "Boost your mood with uplifting affirmations.", hint: "positive thinking" },
              { title: "Breathing Exercise", description: "Practice deep breathing for stress relief.", hint: "breathing exercise" }
            ].map(activity => (
                <Card key={activity.title} className="text-left shadow hover:shadow-md transition-shadow">
                    <CardHeader className="p-0">
                        <Image src={`https://picsum.photos/300/150?random=${activity.title.replace(/\s/g, "")}`} alt={activity.title} width={300} height={150} className="w-full h-36 object-cover rounded-t-md" data-ai-hint={activity.hint} />
                    </CardHeader>
                    <CardContent className="p-4">
                        <CardTitle className="text-lg mb-1">{activity.title}</CardTitle>
                        <CardDescription className="text-sm">{activity.description}</CardDescription>
                        <Button variant="link" className="p-0 mt-2 h-auto text-primary" disabled>Start Activity &rarr;</Button>
                         <p className="text-xs text-muted-foreground mt-1">Coming soon!</p>
                    </CardContent>
                </Card>
            ))}
           </div>
        </div>
      </section>
    </div>
  );
}
