import Image from 'next/image';
import Link from 'next/link';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Palette } from 'lucide-react';
import { INTEREST_CLUBS_DATA } from '@/lib/constants';

export default function InterestClubsPage() {
  return (
    <div className="flex flex-col items-center">
      <section className="w-full py-8 md:py-12 bg-accent/10">
        <div className="container px-4 md:px-6 text-center">
          <Palette className="h-16 w-16 mx-auto text-accent mb-4" />
          <h1 className="text-4xl font-bold tracking-tight">Interest Clubs</h1>
          <p className="mt-3 max-w-xl mx-auto text-lg text-foreground/80">
            Explore your hobbies, showcase projects, and collaborate on challenges with like-minded peers.
          </p>
        </div>
      </section>

      <section className="w-full py-10 md:py-16">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {INTEREST_CLUBS_DATA.map((club) => (
              <Card key={club.id} className="flex flex-col overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader className="p-0">
                   <Image
                    src={`https://picsum.photos/400/200?random=${club.id}`}
                    alt={club.name}
                    width={400}
                    height={200}
                    className="w-full h-48 object-cover"
                    data-ai-hint={club.imageHint}
                  />
                </CardHeader>
                <CardContent className="p-6 flex flex-col flex-grow">
                  <div className="flex items-center gap-3 mb-3">
                     <club.icon className="h-7 w-7 text-accent" />
                    <CardTitle className="text-xl font-semibold">{club.name}</CardTitle>
                  </div>
                  <CardDescription className="text-foreground/70 mb-4 flex-grow">
                    {club.description}
                  </CardDescription>
                  <Button variant="outline" className="mt-auto group w-full border-accent text-accent hover:bg-accent/10 hover:text-accent" disabled>
                    {/* <Link href={`/clubs/${club.id}`}> */}
                      Explore {club.name}
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    {/* </Link> */}
                  </Button>
                   <p className="text-xs text-muted-foreground mt-2 text-center">Feature coming soon!</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
