import Image from 'next/image';
import Link from 'next/link';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { FEATURE_CARDS } from '@/lib/constants';

export default function HomePage() {
  return (
    <div className="flex flex-col items-center justify-center">
      <section className="w-full py-12 md:py-20 lg:py-28 bg-gradient-to-br from-primary/10 via-background to-accent/10">
        <div className="container px-4 md:px-6 text-center">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
            Welcome to <span className="text-primary">Synergy</span><span className="text-accent">Sphere</span>
          </h1>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-foreground/80 md:text-xl">
            Your holistic learning and social platform. Study, create, connect, and grow with fellow CBSE students.
          </p>
          <div className="mt-8">
            <Image
              src="https://picsum.photos/800/400"
              alt="Students collaborating and learning"
              width={800}
              height={400}
              className="rounded-lg shadow-xl mx-auto"
              data-ai-hint="students learning community"
            />
          </div>
        </div>
      </section>

      <section className="w-full py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <h2 className="text-3xl font-bold tracking-tight text-center mb-12">
            Explore Our Features
          </h2>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {FEATURE_CARDS.map((feature) => (
              <Card key={feature.title} className="flex flex-col overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader className="p-0">
                  <Image
                    src={`https://picsum.photos/400/200?random=${Math.random()}`} // ensure different images
                    alt={feature.title}
                    width={400}
                    height={200}
                    className="w-full h-48 object-cover"
                    data-ai-hint={feature.imageHint}
                  />
                </CardHeader>
                <CardContent className="p-6 flex flex-col flex-grow">
                  <div className="flex items-center gap-3 mb-3">
                    <feature.icon className="h-8 w-8 text-primary" />
                    <CardTitle className="text-2xl font-semibold">{feature.title}</CardTitle>
                  </div>
                  <CardDescription className="text-foreground/70 mb-4 flex-grow">
                    {feature.description}
                  </CardDescription>
                  <Button asChild variant="outline" className="mt-auto group">
                    <Link href={feature.href}>
                      Explore {feature.title}
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
