import React from 'react';
import type { LucideIcon, LucideProps } from 'lucide-react';
import { Home, Users, Puzzle, Palette, Smile, BookOpen, TestTube2, Globe, Cpu, Music, Feather, Dumbbell, Leaf, Brain, Paintbrush } from 'lucide-react';

export interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
};

export const NAV_ITEMS: NavItem[] = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/study-planner', label: 'AI Study Planner', icon: Brain },
  { href: '/study-groups', label: 'Study Groups', icon: Users },
  { href: '/quizzes', label: 'Quizzes', icon: Puzzle },
  { href: '/clubs', label: 'Interest Clubs', icon: Palette },
  { href: '/mood-tracker', label: 'Mood Tracker', icon: Smile },
];

export interface FeatureCardItem {
  title: string;
  description: string;
  href: string;
  icon: LucideIcon;
  imageHint: string;
};

export const FEATURE_CARDS: FeatureCardItem[] = [
  {
    title: 'AI Study Planner',
    description: 'Get personalized study schedules tailored to your goals and learning style.',
    href: '/study-planner',
    icon: Brain,
    imageHint: 'organized schedule'
  },
  {
    title: 'Study Groups',
    description: 'Collaborate with peers, share notes, and solve doubts in subject-specific rooms.',
    href: '/study-groups',
    icon: Users,
    imageHint: 'students collaboration'
  },
  {
    title: 'Curriculum Quizzes',
    description: 'Test your knowledge with interactive quizzes aligned with the CBSE syllabus.',
    href: '/quizzes',
    icon: Puzzle,
    imageHint: 'knowledge test'
  },
  {
    title: 'Interest Clubs',
    description: 'Explore hobbies, showcase projects, and connect with like-minded students.',
    href: '/clubs',
    icon: Palette,
    imageHint: 'creative hobbies'
  },
  {
    title: 'Mood Tracker',
    description: 'Log your mood, get positive suggestions, and prioritize your well-being.',
    href: '/mood-tracker',
    icon: Smile,
    imageHint: 'mental wellness'
  },
];

export interface StudyGroup {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  imageHint: string;
};

export const STUDY_GROUPS_DATA: StudyGroup[] = [
  { id: 'math', name: 'Mathematics', description: 'Discuss algebra, geometry, calculus and more.', icon: BookOpen, imageHint: 'math equations' },
  { id: 'physics', name: 'Physics', description: 'Explore mechanics, optics, thermodynamics.', icon: TestTube2, imageHint: 'physics experiment' },
  { id: 'chemistry', name: 'Chemistry', description: 'Delve into reactions, elements, and compounds.', icon: TestTube2, imageHint: 'chemistry lab' },
  { id: 'biology', name: 'Biology', description: 'Learn about life, cells, and ecosystems.', icon: Leaf, imageHint: 'biology microscope' },
  { id: 'english', name: 'English', description: 'Improve literature, grammar, and writing skills.', icon: Feather, imageHint: 'classic books' },
  { id: 'social-studies', name: 'Social Studies', description: 'Understand history, geography, and civics.', icon: Globe, imageHint: 'historical map' },
];

export interface QuizCategory {
  id: string;
  title: string;
  subject: string;
  icon: LucideIcon;
  imageHint: string;
};

export const QUIZZES_DATA: QuizCategory[] = [
  { id: 'math-algebra', title: 'Algebra Fundamentals', subject: 'Mathematics', icon: Puzzle, imageHint: 'algebra quiz' },
  { id: 'physics-motion', title: 'Laws of Motion', subject: 'Physics', icon: Puzzle, imageHint: 'physics quiz' },
  { id: 'chem-periodic', title: 'Periodic Table', subject: 'Chemistry', icon: Puzzle, imageHint: 'chemistry quiz' },
  { id: 'bio-cell', title: 'Cell Biology', subject: 'Biology', icon: Puzzle, imageHint: 'biology quiz' },
];

export interface InterestClub {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  imageHint: string;
};

export const INTEREST_CLUBS_DATA: InterestClub[] = [
  { id: 'coding', name: 'Coding Club', description: 'Learn programming, build projects, and join hackathons.', icon: Cpu, imageHint: 'coding screen' },
  { id: 'art', name: 'Art Club', description: 'Share your artwork, learn new techniques, and collaborate on creative projects.', icon: Paintbrush, imageHint: 'art supplies' },
  { id: 'robotics', name: 'Robotics Club', description: 'Design, build, and program robots for challenges and fun.', icon: Cpu, imageHint: 'robotics parts' },
  { id: 'music', name: 'Music Club', description: 'Play instruments, sing, compose, and appreciate various genres.', icon: Music, imageHint: 'musical instruments' },
  { id: 'writing', name: 'Writing Club', description: 'Share stories, poems, essays, and improve your writing skills.', icon: Feather, imageHint: 'writing journal' },
  { id: 'sports', name: 'Sports Science Club', description: 'Discuss sports, fitness, and human performance.', icon: Dumbbell, imageHint: 'sports equipment' },
  { id: 'environment', name: 'Environment Club', description: 'Promote sustainability and environmental awareness.', icon: Leaf, imageHint: 'nature landscape' },
];

export interface MoodOption {
    value: string;
    label: string;
    icon: LucideIcon;
};

const MehIcon = React.forwardRef<SVGSVGElement, LucideProps>(
  (props, ref) => {
    const {
      size = 24,
      color = "currentColor",
      strokeWidth: propsStrokeWidth = 2,
      className,
      ...restProps
    } = props;

    const numericStrokeWidth = typeof propsStrokeWidth === 'string' ? parseFloat(propsStrokeWidth) : propsStrokeWidth;

    return (
      <svg
        ref={ref}
        xmlns="http://www.w3.org/2000/svg"
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke={color}
        strokeWidth={numericStrokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
        className={className}
        {...restProps}
      >
        <circle cx="12" cy="12" r="10" />
        <line x1="8" y1="15" x2="16" y2="15" />
        <line x1="9" y1="9" x2="9.01" y2="9" />
        <line x1="15" y1="9" x2="15.01" y2="9" />
      </svg>
    );
  }
);
MehIcon.displayName = 'MehIcon';

const FrownIcon = React.forwardRef<SVGSVGElement, LucideProps>(
  (props, ref) => {
    const {
      size = 24,
      color = "currentColor",
      strokeWidth: propsStrokeWidth = 2,
      className,
      ...restProps
    } = props;

    const numericStrokeWidth = typeof propsStrokeWidth === 'string' ? parseFloat(propsStrokeWidth) : propsStrokeWidth;

    return (
      <svg
        ref={ref}
        xmlns="http://www.w3.org/2000/svg"
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke={color}
        strokeWidth={numericStrokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
        className={className}
        {...restProps}
      >
        <circle cx="12" cy="12" r="10" />
        <path d="M16 16s-1.5-2-4-2-4 2-4 2" />
        <line x1="9" y1="9" x2="9.01" y2="9" />
        <line x1="15" y1="9" x2="15.01" y2="9" />
      </svg>
    );
  }
);
FrownIcon.displayName = 'FrownIcon';

const StressedIcon = React.forwardRef<SVGSVGElement, LucideProps>(
 (props, ref) => {
    const {
      size = 24,
      color = "currentColor",
      strokeWidth: propsStrokeWidth = 2,
      className,
      ...restProps
    } = props;

    const numericStrokeWidth = typeof propsStrokeWidth === 'string' ? parseFloat(propsStrokeWidth) : propsStrokeWidth;

    return (
      <svg
        ref={ref}
        xmlns="http://www.w3.org/2000/svg"
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke={color}
        strokeWidth={numericStrokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
        className={className}
        {...restProps}
      >
        <circle cx="12" cy="12" r="10" />
        <path d="M16 12l-1.5-1.5M12 16l-1.5-1.5M8 12l1.5 1.5M12 8l1.5 1.5" />
      </svg>
    );
  }
);
StressedIcon.displayName = 'StressedIcon';

export const MOOD_OPTIONS: MoodOption[] = [
    { value: 'happy', label: 'Happy', icon: Smile },
    { value: 'okay', label: 'Okay', icon: MehIcon },
    { value: 'sad', label: 'Sad', icon: FrownIcon },
    { value: 'stressed', label: 'Stressed', icon: StressedIcon }
];
