'use server';

/**
 * @fileOverview AI-powered study schedule generator.
 *
 * - studyScheduleGenerator - A function that generates a personalized study schedule.
 * - StudyScheduleGeneratorInput - The input type for the studyScheduleGenerator function.
 * - StudyScheduleGeneratorOutput - The return type for the studyScheduleGenerator function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const StudyScheduleGeneratorInputSchema = z.object({
  subjects: z
    .array(z.string())
    .describe('List of subjects the student is studying.'),
  learningHabits: z
    .string()
    .describe(
      'Description of the student’s learning habits, including preferred study times and methods.'
    ),
  quizScores: z
    .record(z.number())
    .describe('Record of quiz scores for each subject.'),
  academicGoals: z
    .string()
    .describe('Description of the student’s academic goals.'),
});
export type StudyScheduleGeneratorInput = z.infer<typeof StudyScheduleGeneratorInputSchema>;

const StudyScheduleGeneratorOutputSchema = z.object({
  schedule: z
    .string()
    .describe('A personalized study schedule outlining study times for each subject.'),
  recommendations: z
    .string()
    .describe(
      'Additional recommendations for improving study habits and academic performance.'
    ),
});
export type StudyScheduleGeneratorOutput = z.infer<typeof StudyScheduleGeneratorOutputSchema>;

export async function studyScheduleGenerator(
  input: StudyScheduleGeneratorInput
): Promise<StudyScheduleGeneratorOutput> {
  return studyScheduleGeneratorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'studyScheduleGeneratorPrompt',
  input: {schema: StudyScheduleGeneratorInputSchema},
  output: {schema: StudyScheduleGeneratorOutputSchema},
  prompt: `You are an AI study planner that generates personalized study schedules for students.

  Based on the student's subjects, learning habits, quiz scores, and academic goals, create a study schedule that optimizes their study time and improves their academic performance.

  Subjects: {{subjects}}
  Learning Habits: {{learningHabits}}
  Quiz Scores: {{quizScores}}
  Academic Goals: {{academicGoals}}

  Schedule:
  `,
});

const studyScheduleGeneratorFlow = ai.defineFlow(
  {
    name: 'studyScheduleGeneratorFlow',
    inputSchema: StudyScheduleGeneratorInputSchema,
    outputSchema: StudyScheduleGeneratorOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
