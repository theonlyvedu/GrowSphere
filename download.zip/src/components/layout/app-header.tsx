'use client';

import Link from 'next/link';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { Logo } from '@/components/icons/logo';
import { Button } from '@/components/ui/button';
import { PanelLeftOpen } from 'lucide-react';

export function AppHeader() {
  return (
    <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background/80 px-4 backdrop-blur md:px-6">
      <div className="flex items-center gap-2 md:hidden">
        <SidebarTrigger asChild>
          <Button variant="ghost" size="icon">
            <PanelLeftOpen className="h-6 w-6" />
            <span className="sr-only">Toggle Sidebar</span>
          </Button>
        </SidebarTrigger>
      </div>
      <Link href="/" className="flex items-center gap-2 text-lg font-semibold md:text-base">
        <Logo className="h-8 w-8" />
        <span className="font-bold text-xl text-primary">SynergySphere</span>
      </Link>
      <div className="flex-1" />
      {/* Future: User profile, notifications */}
    </header>
  );
}
